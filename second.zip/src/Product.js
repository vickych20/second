const Products = [
  {
    id: 1,
    name: "Dark king M2435 Mechanical keybord-free 31 key",
    image:
      "https://images.unsplash.com/photo-1618424181497-157f25b6ddd5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8bGFwdG9wJTIwY29tcHV0ZXJ8ZW58MHx8MHx8&w=1000&q=80",
    desc: "lerem",
    price: 2424,
    address: "New Delhi",
    sold: 12,
    rating: 4,
    tag: "laptop",
  },
  {
    id: 2,
    name: "Dark king M2435 Mechanical keybord-free 31 key",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSi7gqYpJMmbkOgExiuY436POtV0h7lZUkVC_FrvAMN&s",
    desc: "lerem",
    price: 2424,
    address: "New Delhi",
    sold: 12,
    rating: 4,
    tag: "laptop",
  },
  {
    id: 3,
    name: "Dark king M2435 Mechanical keybord-free 31 key",
    image:
      "https://thumbs.dreamstime.com/b/hands-computer-desk-using-laptop-rustic-wood-background-cup-tea-book-globe-glasses-53253551.jpg",
    desc: "lerem",
    price: 2424,
    address: "New Delhi",
    sold: 12,
    rating: 4,
    tag: "laptop",
  },
  {
    id: 4,
    name: "Dark king M2435 Mechanical keybord-free 31 key",
    image:
      "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bGFwdG9wJTIwY29tcHV0ZXJ8ZW58MHx8MHx8&w=1000&q=80",
    desc: "lerem",
    price: 2424,
    address: "New Delhi",
    sold: 12,
    rating: 4,
    tag: "mobile",
  },
  {
    id: 5,
    name: "Dark king M2435 Mechanical keybord-free 31 key",
    image:
      "https://images.all-free-download.com/images/graphiclarge/laptop_vector_model_194224.jpg",
    desc: "lerem",
    price: 2424,
    address: "New Delhi",
    sold: 12,
    rating: 4,
    tag: "mobile",
  },
];

export default Products;