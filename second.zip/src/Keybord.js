const Keybord = [
  {
    id: 1,
    name: "Dark king M2435 Mechanical keybord-free 31 keys",
    image:
      "https://navbharattimes.indiatimes.com/thumb/msid-93992535,imgsize-104738,width-540,height-405,resizemode-75/best-running-shoes-93992535.jpg",
    desc: "or football field to find more great stock photos and pictures",

    address: "New Delhi",
    price:8763,
    sold: 12,
    rating: 4,
    tag: "laptop",
    location: "delhi",
  },
  {
    id: 2,
    name: "Dark king M2435 Mechanical keybord-free 31 keys",
    image:
      "https://content-management-files.canva.com/cdn-cgi/image/f=auto,q=70/2fdbd7ab-f378-4c63-8b21-c944ad2633fd/header_t-shirts2.jpg",
    desc: "or football field to find more great stock photos and pictures",
    price: 3243,
    sold: 13,
    rating: 5,
    tag: "keybord",
    location: "delhi",
  },
  {
    id: 3,
    name: "Dark king M2435 Mechanical keybord-free 31 keys",
    image:
      "https://images.bewakoof.com/t640/black-dazzling-blue-raglan-half-sleeve-t-shirt-333117-1660652688-1.jpg",
    desc: "or football field to find more great stock photos and pictures",
    price: 3243,
    sold: 13,
    rating: 5,
    tag: "keybord",
  },
  {
    id: 4,
    name: "Dark king M2435 Mechanical keybord-free 31 keysl",
    image:
      "https://thumbs.dreamstime.com/b/football-soccer-ball-kickoff-game-sunset-38302251.jpg",
    desc: "or football field to find more great stock photos and pictures",
    price: 3243,
    sold: 13,
    rating: 5,
    tag: "keybord",
    location: "delhi",
  },
  {
    id: 5,
    name: "Dark king M2435 Mechanical keybord-free 31 keys",
    image: "https://www.venusrubbers.com/images/mercury-ball.jpg",
    desc: "or football field to find more great stock photos and pictures",
    price: 3243,
    sold: 13,
    rating: 5,
    tag: "keybord",
    location: "delhi",
  },
];
export default Keybord;