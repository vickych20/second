import React from 'react'
import img from '../images/img.png'

export default function Full() {
  return (
      <div className='relative bottom-[5rem]'>
          <img src={img} alt="" className='w-full' />
          


    </div>
  )
}
